package com.example.eva3_2_threads;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Simular una actividad que dure mucho tiempo
        //por ejemplo una conexion a BD
        //10s
      /*  for (int i = 0; i < 10; i++){
            //duerme al hilo principal
            try {
                Thread.sleep(1000);//1 s - 1000 milisegundos
            } catch (InterruptedException e) {
                e.printStackTrace();
            }*/
      final Thread tHilo1 = new Thread() {
          @Override
          public void run() {//aqui es donde va el trabajo en segundo plano
              super.run();
              //aqui
              for (int i = 0; i < 10; i++){
                  //duerme al hilo principal
                  try {
                      Thread.sleep(1000);//1 s - 1000 milisegundos
                      Log.wtf("tHilo1",i + "");
                  } catch (InterruptedException e) {
                      e.printStackTrace();
                  }

              }

          }

      };
        tHilo1.start();


      }
    }

